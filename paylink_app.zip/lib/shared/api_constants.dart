class ApiConstants {
  static const String apiEndpoint =
      'http://192.168.254.104:8080/api/';

// move functions to tjis class
// add jeaders
}
